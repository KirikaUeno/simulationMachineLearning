import io
import pickle

print("start python predict")
f = io.open("inputParametersValues.txt", 'r', encoding='utf-8', newline='\n', errors='ignore')
x_test = []
for line in f:
    x_test.append(float(line[:-1]))

print(x_test)
filename = 'treeModel.sav'
regr = pickle.load(open(filename, 'rb'))
pred = regr.predict([list(x_test)])
y=[]
for j in range(len(pred[0])):
    y.append(pred[0,j].item())
print(y)

info = ""
f = open("predictOutput.txt", "w")
for i in range(len(pred[0])):
    info += str(y[i]) + "\n"
f.write(info)
f.close()